package com.example.po;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

class pokemonAdapter  extends RecyclerView.Adapter {
   ArrayList<pokemon>poArry;
   Context context;

    public pokemonAdapter(ArrayList<pokemon> poArry, Context context) {
        this.poArry = poArry;
        this.context = context;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
       View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.pokemon1,parent,false);
       ViewHolder vh = new ViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        ((ViewHolder)holder).image.setImageResource(poArry.get(position).getImage());
        ((ViewHolder)holder).name.setText(poArry.get(position).getName()+"");
        ((ViewHolder)holder).total.setText(poArry.get(position).getTotal()+"");

    }

    @Override
    public int getItemCount() {
        return poArry.size();
    }


   public static class ViewHolder extends RecyclerView.ViewHolder{
       public ImageView image;
       public TextView name;
       public TextView total;
       public View view;

       public ViewHolder(@NonNull View itemView) {
           super(itemView);
           view = itemView;
           image = itemView.findViewById(R.id.imageView);
           name = itemView.findViewById(R.id.textView2);
           total = itemView.findViewById(R.id.textView3);

       }
   }
}
